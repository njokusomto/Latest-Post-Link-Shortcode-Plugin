=== WordPress Latest Post Shortcode Plugin ===
Contributors: njokusomto
Donate link: https://paypal.me/TheDevOne
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin creates a shortcode for you to turn your last WordPress post into a link. You can add this shortcode to your any link field or URL field in the post editor.

== Description ==

This plugin creates a shortcode for you to turn your last WordPress post into a link. You can add this shortcode to your any link field or URL field in the post editor.

Simply use shortcode [latestposturl] in your post editor to link to the latest post on your blog/website. This shortcode works on popular post editors like the Classic Editor, Gutenberg Editor as well as third-party page builders like Elementor and Visual Composer.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Plugin usage in the default WordPress post editor.
2. Plugin usage in the elementor page builder.

== Changelog ==

= 1.0 =
* Initial plugin release.