<?php
/*
   Plugin Name: Latest Post Shortcode Link
   Plugin URI: http://wordpress.org/extend/plugins/latest-post-shortcode-link/
   Version: 1.0
   Author: Sommie Njoku
   Description: This plugin creates a shortcode for you to turn your last WordPress post into a link.
   Text Domain: latest-post-shortcode-link
   License: GPLv3
*/

add_shortcode( 'latestposturl', 'shortcode_latestposturl' );
 
function shortcode_latestposturl() {
 
    // Get the latest post
    $latestpost = get_posts( array(
        'numberposts' => 1,
    ) );
 
    if ( empty( $latestpost ) )
        return '#';
 
    return get_permalink( $latestpost[0]->ID );
}

